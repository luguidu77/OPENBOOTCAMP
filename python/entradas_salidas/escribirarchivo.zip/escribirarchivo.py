f= open('fichero.txt', 'a')
f.write('primera linea\n')

f.close

f= open('fichero.txt', 'a')
f.write('segunda linea\n')

f.close


