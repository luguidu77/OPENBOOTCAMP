def divide(a, b):

    return a / b