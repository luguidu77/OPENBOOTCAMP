def multiplica(a, b):

    return a * b