def resta(a, b):
   
    """
        REALIZA LA RESTA a - b
    """
   
   
    return a - b

   
    
    